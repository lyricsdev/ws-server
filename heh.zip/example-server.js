var WebSocketServer = require('ws').Server;
var http = require('http');
var server = http.createServer();
var wss = new WebSocketServer({server: server, path: '/foo'});
const {getcommand} = require('./commandhandler.js');
const {setup} = require('./modules/database.setup.js');
setup();
const {decrypt, encrypt} = require('./commands/encryptest.js');
wss.on('connection', function(ws) {
    console.log('/foo connected');
    ws.on('message', function(data, flags) {
       const msg = JSON.parse(decrypt(data));
        console.log(msg)
        getcommand(msg,ws);
    });
    ws.on('close', function() {
      console.log('Connection closed!');
    });
    ws.on('error', function(e) {
    });
    
});
server.listen(8126);
