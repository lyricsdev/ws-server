
let makeback = {
    message: 'Hello World',
    type: "123",
    uuid: ""
}

exports.makeback = makeback;
